def pisze():
    print('pisze coś z ppm !!!')