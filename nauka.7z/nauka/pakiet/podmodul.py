

def pisz():
    print('pisze siema !!!')